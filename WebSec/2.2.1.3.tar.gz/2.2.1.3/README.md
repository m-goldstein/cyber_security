# README
## Files
brute_force - multi-threaded python script to generate random passwords and check their hash for valid escape
charachters that would produce an SQL injection on the server
make_request.py - helper script to read password files and submit requests to the server using the generated passwords
kill_python - bash script to kill instances of python3; good when C-C doesn't work or if the shell goes unresponsive
## How to run
 Everything is encapsulated into brute_force for you.
 There are some parameters at the top you can adjust to tweak the execution profile (ie. number of worker threads,
 max number of charachters to use in a random password, upper bound on the range of unicode identifiers to use in a password)
 To run, type ./brute_force.
 The password file(s) we used to login as victim is included in the data/good_password files

